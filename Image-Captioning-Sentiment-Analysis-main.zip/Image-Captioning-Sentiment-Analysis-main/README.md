# Image-Captioning-Sentiment-Analysis
You can find the images in this link : https://drive.google.com/drive/folders/13Q-ixjN5kntF6XP83w5bOoMh-e_adPOR?usp=drive_link
# -------------
If you want to see the fine-tuned models you can check the project in my google colab link : 
https://drive.google.com/drive/folders/1limnKzvIypNr9XjYRdfR-I0dHA5wrf9w?usp=drive_link
